thisset = {'apple', 'banana', 'cherry'}
thisset.add('berries')
thisset.update(['jack fruit', 'orange'])
print(thisset)

thisset.remove('orange')
thisset.discard('asbdfjh')
print(thisset)
