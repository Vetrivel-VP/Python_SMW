if __name__ == "__main__":
    def x(a): return a + 10
    print(x(5))
