import camelcase

c = camelcase.CamelCase()

text = "hai there, my first external downloded package"

print(c.hump(text))
