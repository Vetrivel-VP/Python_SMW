from ecommerce import sales

sales.accnt_details()
sales.sales_details()
