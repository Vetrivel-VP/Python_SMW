def sales_details():
    print('some sales details inside this function')


def accnt_details():
    print('print some of your account detaisl here')
