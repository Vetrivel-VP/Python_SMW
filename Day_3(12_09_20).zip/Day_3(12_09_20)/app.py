for i in range(5):
    print(f'{i} : Hello World')

"""
    i = 0       i  <  5    0<5
            0 : Hello world     i= i + 1
    i = 1       1 < 5
            1 : Hello world     1 + 1
    i = 2       2 < 5
            2 : Hello world     2 +1
    i = 3       3 < 5
            3 : Hello World     3 + 1
    i = 4       4 < 5
            4 : Hello World     4 + 1
    i = 5       5 < 5
        Lopp terminated             

"""

0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11

for i in range(1, 10 + 1):
    print(f'{i} : Hello World')
