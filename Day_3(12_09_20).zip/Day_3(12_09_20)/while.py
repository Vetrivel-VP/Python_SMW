name = input('Enter the name:')
i = 1
while i <= 5:
    print(f'{i} : {name}')
    i = i + 1  # i += 1
