a, b = 5, 10
c = a + b
print(f'{a} + {b} = {c}')           # 5 + 10 = 15

print(f'5 + 10 = {5+10}')
