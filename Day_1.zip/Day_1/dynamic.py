a, b = eval(input('Enter the value for a,b:'))
print(f'{a} + {b} = {a+b}')
