print("Hello world")
x = 2
