a = eval(input('Enter the value of a:'))
if a >= 30:
    print(f'{a} is greater than 30')
else:
    print(f'{a} is not greater than 30')
